package com.example.election_exit_poll_620710118

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
