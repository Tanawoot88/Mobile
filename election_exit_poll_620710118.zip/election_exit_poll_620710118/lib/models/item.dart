class item {
  final int number;
  final String title;
  final String name;
  final String surname;

  item({
    required this.number,
    required this.title,
    required this.name,
    required this.surname,
  });

  factory item.fromJson(Map<String, dynamic> json) {
    return item(
      number: json['number'],
      title: json['title'],
      name: json['name'],
      surname: json['image'],
    );
  }

  item.fromJson2(Map<String, dynamic> json)
      : number = json['number'],
        title = json['title'],
        name = json['name'],
        surname = json['image'];

  @override
  String toString() {
    return '';
  }
}